#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "entity.h"
#include <stdio.h>
#include <stdbool.h>

#define SCREEN_W 1024
#define SCREEN_H 768

int main()
{
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        return 1;
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG))
        return 1;

    SDL_Surface *screen = SDL_SetVideoMode(SCREEN_W, SCREEN_H, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("Enemy AI with Collision & Attack", NULL);

    SDL_Surface *world = IMG_Load("War4.png");
    SDL_Surface *worldMask = IMG_Load("War4_mask.png");
    SDL_Surface *playerSprite = IMG_Load("player.png");

    if (world->w != SCREEN_W || world->h != SCREEN_H)
    {
        SDL_Surface *scaled = SDL_CreateRGBSurface(SDL_SWSURFACE, SCREEN_W, SCREEN_H, 32,
                                                   0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        SDL_SoftStretch(world, NULL, scaled, NULL);
        SDL_FreeSurface(world);
        world = scaled;
    }

    SDL_Rect playerPos = {
        .x = 500,
        .y = 400,
        .w = 0,
        .h = 0};

    if (playerSprite)
    {
        playerPos.w = playerSprite->w;
        playerPos.h = playerSprite->h;
    }
    else
    {
        printf("Failed to load player sprite: %s\n", IMG_GetError());
        playerPos.w = 64;
        playerPos.h = 64;
    }

    // Load coin count

    Entity enemy;
    initEntity(&enemy, "sprites.png", 324, 555);
    enemy.attackRange = 80;

    bool running = true;
    SDL_Event event;
    SDL_Rect bgPos = {0, 0, SCREEN_W, SCREEN_H};
    initCoinSystem();
    int totalCoinsCollected = 0;

    // Add your coin types (call this once at startup)
    addCoinType("coin.png", 'B', 1);  // Bronze coin = 1 point
    addCoinType("coin.png", 'S', 5);  // Silver coin = 5 points
    addCoinType("coin.png", 'G', 10); // Gold coin = 10 points

    // Place coins in your level
    placeCoin('B', 100, 200); // Bronze coin at (100,200)
    placeCoin('S', 400, 300); // Silver coin at (400,300)
    placeCoin('G', 700, 150); // Gold coin at (700,150)

    while (running)
    {
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
                running = false;
            else if (event.type == SDL_KEYDOWN)
            {
                switch (event.key.keysym.sym)
                {
                case SDLK_h:
                    triggerHurt(&enemy);
                    break;
                case SDLK_d:
                    triggerDeath(&enemy);
                    break;
                case SDLK_ESCAPE:
                    running = false;
                    break;
                case SDLK_LEFT:
                    playerPos.x -= 10;
                    break;
                case SDLK_RIGHT:
                    playerPos.x += 10;
                    break;
                case SDLK_UP:
                    playerPos.y -= 10;
                    break;
                case SDLK_DOWN:
                    playerPos.y += 10;
                    break;
                default:;
                    break;
                }
            }
        }

        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 40, 40, 40));

        SDL_BlitSurface(world, NULL, screen, &bgPos);

        if (CollisionParfaite_PNG(&enemy, worldMask))
        {
            printf("Collision detected with environment!\n");
            enemy.state = (enemy.state == DIR_RIGHT) ? DIR_LEFT : DIR_RIGHT;
        }

        updateEntity(&enemy, SCREEN_W, SCREEN_H, playerPos);

        drawEntity(&enemy, screen);

        if (playerSprite)
        {
            SDL_BlitSurface(playerSprite, NULL, screen, &playerPos);
        }
        else
        {
            SDL_FillRect(screen, &playerPos, SDL_MapRGB(screen->format, 0, 0, 255));
        }


        // In your game loop:
        int collectedValue = checkCoinCollisions(playerPos);
        if (collectedValue > 0) {
            printf("Collected %d points! Total: %d\n", collectedValue, totalCoinsCollected);
        }
        drawAllCoins(screen);

        SDL_Flip(screen);
        SDL_Delay(16);
    }

    SDL_FreeSurface(world);
    SDL_FreeSurface(worldMask);
    if (playerSprite)
        SDL_FreeSurface(playerSprite);
    freeEntity(&enemy);
    saveCoinsToFile();
    freeCoinSystem();
    IMG_Quit();
    SDL_Quit();
    return 0;
}